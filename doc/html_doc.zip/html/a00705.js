var a00705 =
[
    [ "column", "a00705.html#aeeef678c56ecaa175b01ece97e8e48a9", null ],
    [ "row", "a00705.html#a1b23084488010cb319f7c312a6861af5", null ],
    [ "value", "a00705.html#a59d7497b5d920b6578002bec94a16f0b", null ]
];