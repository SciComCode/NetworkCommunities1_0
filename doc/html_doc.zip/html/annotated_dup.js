var annotated_dup =
[
    [ "NetworkCommunities", null, [
      [ "FuzzyCommunities", "a00925.html", "a00925" ],
      [ "SparseArray", "a00929.html", "a00929" ]
    ] ]
];