var searchData=
[
  ['modularity',['modularity',['../a00925.html#a1cb4e67ad2887995287a1b299b20c178',1,'NetworkCommunities::FuzzyCommunities']]]
];
