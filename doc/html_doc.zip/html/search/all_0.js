var searchData=
[
  ['alpha_5fbrent',['alpha_Brent',['../a00925.html#acd6852bc41a419b9eb9d0a6ffe285ba8',1,'NetworkCommunities::FuzzyCommunities']]],
  ['alpha_5fbrent_5fparallel',['alpha_Brent_parallel',['../a00925.html#a642e09f295e0a56a02064c506fc005ee',1,'NetworkCommunities::FuzzyCommunities']]],
  ['alpha_5fnr',['alpha_NR',['../a00925.html#aee9b01e54e2275041790c1e55f12df70',1,'NetworkCommunities::FuzzyCommunities']]],
  ['alpha_5fnr_5fparallel',['alpha_NR_parallel',['../a00925.html#a3f9a4a635099ff52cf165403f725dd1a',1,'NetworkCommunities::FuzzyCommunities']]]
];
