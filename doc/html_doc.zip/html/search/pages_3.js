var searchData=
[
  ['software_20architecture',['Software architecture',['../a00935.html',1,'']]]
];
