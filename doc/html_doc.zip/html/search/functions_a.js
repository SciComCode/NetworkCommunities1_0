var searchData=
[
  ['setncomm',['setNComm',['../a00925.html#a21d11e8249f9a47ccb073424ee107523',1,'NetworkCommunities::FuzzyCommunities']]],
  ['sii',['sii',['../a00925.html#a56b944d850b4bc24b099c05e48ef2b78',1,'NetworkCommunities::FuzzyCommunities']]],
  ['siih',['siih',['../a00925.html#a455bb35794dfd58dae57dbb4d1a24935',1,'NetworkCommunities::FuzzyCommunities']]],
  ['sij',['sij',['../a00925.html#a7b6676b0f9807ee905a463731d9e58bc',1,'NetworkCommunities::FuzzyCommunities']]],
  ['sijh',['sijh',['../a00925.html#a01809a5e3f478434db3bc599c4d14f93',1,'NetworkCommunities::FuzzyCommunities']]],
  ['sparsearray',['SparseArray',['../a00929.html#a6b6b0910cb4d9c44918126bbe639c1fb',1,'NetworkCommunities::SparseArray']]]
];
