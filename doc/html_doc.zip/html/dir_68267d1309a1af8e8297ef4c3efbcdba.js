var dir_68267d1309a1af8e8297ef4c3efbcdba =
[
    [ "FuzzyCommunities.h", "a00617.html", [
      [ "FuzzyCommunities", "a00637.html", "a00637" ]
    ] ],
    [ "SparseArray.h", "a00629.html", [
      [ "SparseArray", "a00641.html", "a00641" ],
      [ "element", "a00645.html", "a00645" ]
    ] ]
];