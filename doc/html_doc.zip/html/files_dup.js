var files_dup =
[
    [ "FuzzyCommunities.h", "a00905.html", [
      [ "FuzzyCommunities", "a00925.html", "a00925" ]
    ] ],
    [ "SparseArray.h", "a00917.html", [
      [ "SparseArray", "a00929.html", "a00929" ],
      [ "element", "a00933.html", "a00933" ]
    ] ]
];